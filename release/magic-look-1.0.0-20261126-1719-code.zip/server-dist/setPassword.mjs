import { resolve, dirname } from "node:path";
import { createInterface } from "node:readline/promises";
import { fileURLToPath } from "node:url";
import { w as writeStoredConfig, h as hashPassword, r as readStoredConfig, a as CONFIG_FILE } from "./chunks/auth-BD_DdyMd.mjs";
import "node:crypto";
import "node:fs";
const MIN_LENGTH = 10;
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const rl = createInterface({ input: process.stdin, terminal: false });
const lines = rl[Symbol.asyncIterator]();
const ask = async (prompt) => {
  process.stdout.write(prompt);
  const { value } = await lines.next();
  return typeof value === "string" ? value : "";
};
const password = await ask(`كلمة مرور لوحة التحكم (${MIN_LENGTH} أحرف على الأقل): `);
const again = await ask("أعد كتابتها: ");
rl.close();
if (password.length < MIN_LENGTH) {
  console.error(`كلمة المرور قصيرة: ${MIN_LENGTH} أحرف على الأقل.`);
  process.exit(1);
}
if (password !== again) {
  console.error("الكلمتان مختلفتان.");
  process.exit(1);
}
writeStoredConfig(root, { ...readStoredConfig(root), passwordHash: hashPassword(password) });
console.log(`حُفظت في ${CONFIG_FILE}. أعد تشغيل الخادم لتعمل.`);
