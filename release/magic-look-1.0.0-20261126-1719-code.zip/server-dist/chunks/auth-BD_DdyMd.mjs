import { randomBytes, scryptSync, timingSafeEqual, createHmac } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
const CONFIG_FILE = "server.config.json";
const flag = (value, fallback) => value === void 0 ? fallback : ["1", "true", "yes"].includes(value.toLowerCase());
function readStoredConfig(root) {
  const file = resolve(root, CONFIG_FILE);
  return existsSync(file) ? JSON.parse(readFileSync(file, "utf8")) : {};
}
function writeStoredConfig(root, config) {
  writeFileSync(resolve(root, CONFIG_FILE), `${JSON.stringify(config, null, 2)}
`);
}
function loadConfig(root, env = process.env) {
  const stored = readStoredConfig(root);
  const sessionSecret = stored.sessionSecret ?? randomBytes(32).toString("base64url");
  if (!stored.sessionSecret) writeStoredConfig(root, { ...stored, sessionSecret });
  return {
    port: Number(env.PORT ?? stored.port ?? 8080),
    host: env.HOST ?? stored.host ?? "0.0.0.0",
    passwordHash: stored.passwordHash ?? null,
    sessionSecret,
    secureCookies: flag(env.SECURE_COOKIES, stored.secureCookies ?? false),
    trustProxy: flag(env.TRUST_PROXY, stored.trustProxy ?? false)
  };
}
const COOKIE = "ml_session";
const SESSION_SECONDS = 12 * 60 * 60;
const MAX_ATTEMPTS = 10;
const LOCK_MS = 15 * 60 * 1e3;
const CSRF_HEADER = "x-dashboard";
function hashPassword(password) {
  const salt = randomBytes(16);
  return `scrypt$${salt.toString("base64")}$${scryptSync(password, salt, 64).toString("base64")}`;
}
function verifyPassword(password, stored) {
  const [scheme, salt, hash] = stored.split("$");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const expected = Buffer.from(hash, "base64");
  const actual = scryptSync(password, Buffer.from(salt, "base64"), expected.length);
  return timingSafeEqual(actual, expected);
}
const sign = (secret, payload) => createHmac("sha256", secret).update(payload).digest("base64url");
function createToken(secret, now) {
  const payload = Buffer.from(JSON.stringify({ exp: now + SESSION_SECONDS * 1e3 })).toString("base64url");
  return `${payload}.${sign(secret, payload)}`;
}
function verifyToken(secret, token, now) {
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return false;
  const expected = Buffer.from(sign(secret, payload));
  const actual = Buffer.from(signature);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return false;
  try {
    const { exp } = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return typeof exp === "number" && exp > now;
  } catch {
    return false;
  }
}
function readCookie(req, name) {
  for (const part of (req.headers.cookie ?? "").split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === name) return value.join("=");
  }
  return null;
}
class SessionAuth {
  constructor(settings, now = Date.now) {
    this.settings = settings;
    this.now = now;
  }
  required = true;
  attempts = /* @__PURE__ */ new Map();
  isAuthenticated(req) {
    const token = readCookie(req, COOKIE);
    return token !== null && verifyToken(this.settings.sessionSecret, token, this.now());
  }
  login(req, res, password) {
    if (!this.settings.passwordHash) return "not-configured";
    const ip = this.clientIp(req);
    const record = this.attempts.get(ip);
    if (record && record.count >= MAX_ATTEMPTS && record.until > this.now()) return "locked";
    if (!verifyPassword(password, this.settings.passwordHash)) {
      const fresh = !record || record.until <= this.now();
      this.attempts.set(ip, { count: fresh ? 1 : record.count + 1, until: this.now() + LOCK_MS });
      return "wrong";
    }
    this.attempts.delete(ip);
    this.setCookie(res, createToken(this.settings.sessionSecret, this.now()), SESSION_SECONDS);
    return "ok";
  }
  logout(res) {
    this.setCookie(res, "", 0);
  }
  clientIp(req) {
    const forwarded = this.settings.trustProxy ? String(req.headers["x-forwarded-for"] ?? "").split(",")[0]?.trim() : "";
    return forwarded || req.socket.remoteAddress || "unknown";
  }
  setCookie(res, value, maxAge) {
    const secure = this.settings.secureCookies ? "; Secure" : "";
    res.setHeader("Set-Cookie", `${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure}`);
  }
}
export {
  CSRF_HEADER as C,
  SessionAuth as S,
  CONFIG_FILE as a,
  hashPassword as h,
  loadConfig as l,
  readStoredConfig as r,
  writeStoredConfig as w
};
