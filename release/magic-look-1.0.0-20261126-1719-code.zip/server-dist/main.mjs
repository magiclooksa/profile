import { createServer } from "node:http";
import { resolve, basename, extname, relative, sep, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { C as CSRF_HEADER, l as loadConfig, S as SessionAuth } from "./chunks/auth-BD_DdyMd.mjs";
import { existsSync, readFileSync, mkdirSync, writeFileSync, createWriteStream, readdirSync, rmSync, statSync, createReadStream } from "node:fs";
import { execFileSync, spawn } from "node:child_process";
import "node:crypto";
const PAGES_DIR = "pages";
const PUBLIC_DIR = "public";
const DATA_DIR = "public/data";
const OUT_DIR = "dist";
const STORAGE_DIR = "storage";
const projectPaths = (root2) => ({
  pages: resolve(root2, PAGES_DIR),
  public: resolve(root2, PUBLIC_DIR),
  data: resolve(root2, DATA_DIR),
  out: resolve(root2, OUT_DIR),
  src: resolve(root2, "src"),
  releases: resolve(root2, STORAGE_DIR, "releases"),
  history: resolve(root2, STORAGE_DIR, "history"),
  /** An HTML entry point, given its address in the site (e.g. "services/majlis.html"). */
  page: (href) => resolve(root2, PAGES_DIR, href)
});
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
function sendJson(res, status, body) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(typeof body === "string" ? body : JSON.stringify(body));
}
function sendError(res, error) {
  const status = error instanceof HttpError ? error.status : 500;
  const message = error instanceof Error ? error.message : String(error);
  if (status === 500) console.error(error);
  sendJson(res, status, { error: status === 500 ? `خطأ في الخادم: ${message}` : message });
}
function readText(req, limit) {
  return new Promise((done, fail) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > limit) {
        fail(new HttpError(413, "المحتوى أكبر من المسموح"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => done(Buffer.concat(chunks).toString("utf8")));
    req.on("error", fail);
  });
}
async function readJson(req, limit) {
  const text = await readText(req, limit);
  try {
    return JSON.parse(text);
  } catch {
    throw new HttpError(400, "المحتوى ليس JSON صحيحاً");
  }
}
const MEDIA_FILE = /\.(jpe?g|png|webp|avif|gif|svg|mp4|webm|mov)$/i;
const MEDIA_DIRS = ["images", "videos", "assets", "og"];
const UPLOAD_DIR = "images/uploads";
const MAX_UPLOAD = 300 * 1024 * 1024;
const BACKUPS_PER_FILE = 30;
function listFiles(dir, pattern, base = dir) {
  if (!existsSync(dir)) return [];
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const path = resolve(dir, entry.name);
    if (entry.isDirectory()) return listFiles(path, pattern, base);
    return pattern.test(entry.name) ? [relative(base, path).split(sep).join("/")] : [];
  }).sort();
}
function resolveDocument(dataDir, path) {
  const file = resolve(dataDir, path);
  if (!file.startsWith(dataDir + sep) || !file.endsWith(".json")) {
    throw new HttpError(400, `مسار غير مسموح: ${path}`);
  }
  return file;
}
function safeFileName(name) {
  const ext = extname(name).toLowerCase();
  const stem = basename(name, extname(name)).toLowerCase().replace(/[^a-z0-9.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  return `${stem || "file"}${ext}`;
}
class ContentFiles {
  constructor(paths2, now = () => /* @__PURE__ */ new Date()) {
    this.paths = paths2;
    this.now = now;
  }
  listDocuments() {
    return listFiles(this.paths.data, /\.json$/);
  }
  readDocument(path) {
    const file = resolveDocument(this.paths.data, path);
    if (!existsSync(file)) throw new HttpError(404, `الملف غير موجود: ${path}`);
    return readFileSync(file, "utf8");
  }
  /** Replaces a document, keeping the previous version in the history folder. */
  writeDocument(path, value) {
    const file = resolveDocument(this.paths.data, path);
    if (existsSync(file)) this.backup(path, readFileSync(file, "utf8"));
    mkdirSync(resolve(file, ".."), { recursive: true });
    writeFileSync(file, `${JSON.stringify(value, null, 2)}
`);
  }
  listMedia() {
    return MEDIA_DIRS.flatMap((dir) => listFiles(resolve(this.paths.public, dir), MEDIA_FILE, this.paths.public));
  }
  /** Streams an upload into public/images/uploads/<year-month>/ and returns its path in the site. */
  saveUpload(req, originalName) {
    const name = safeFileName(originalName);
    if (!MEDIA_FILE.test(name)) throw new HttpError(400, "نوع الملف غير مسموح: صور أو فيديو فقط");
    const declared = Number(req.headers["content-length"] ?? 0);
    if (declared > MAX_UPLOAD) throw new HttpError(413, "الملف أكبر من 300 ميغابايت");
    const month = this.now().toISOString().slice(0, 7);
    const dir = resolve(this.paths.public, UPLOAD_DIR, month);
    mkdirSync(dir, { recursive: true });
    let target = name;
    for (let i = 2; existsSync(resolve(dir, target)); i++) {
      target = `${basename(name, extname(name))}-${i}${extname(name)}`;
    }
    const file = resolve(dir, target);
    return new Promise((done, fail) => {
      const out = createWriteStream(file);
      let size = 0;
      const abort = (error) => {
        out.destroy();
        rmSync(file, { force: true });
        fail(error);
      };
      req.on("data", (chunk) => {
        size += chunk.length;
        if (size > MAX_UPLOAD) {
          req.destroy();
          abort(new HttpError(413, "الملف أكبر من 300 ميغابايت"));
        }
      });
      req.on("error", abort);
      out.on("error", abort);
      out.on("finish", () => done(`${UPLOAD_DIR}/${month}/${target}`));
      req.pipe(out);
    });
  }
  backup(path, text) {
    const dir = resolve(this.paths.history, path.replace(/[\\/]/g, "__"));
    mkdirSync(dir, { recursive: true });
    const stamp = this.now().toISOString().replace(/[:.]/g, "-");
    writeFileSync(resolve(dir, `${stamp}.json`), text);
    const versions = readdirSync(dir).sort();
    for (const old of versions.slice(0, Math.max(0, versions.length - BACKUPS_PER_FILE))) rmSync(resolve(dir, old));
  }
}
const CONTENT_API = "/__content";
const MAX_DOCUMENT = 5 * 1024 * 1024;
const LOGIN_MESSAGES = {
  wrong: [401, "كلمة المرور غير صحيحة"],
  locked: [429, "محاولات كثيرة. حاول بعد ربع ساعة"],
  "not-configured": [503, "لم تُضبط كلمة مرور بعد. شغّل على الخادم: npm run set-password"]
};
function createContentHandler({ files, publisher, gate }) {
  async function route(req, res) {
    const url = new URL(req.url ?? "/", "http://localhost");
    const path = url.pathname.slice(CONTENT_API.length);
    const method = req.method ?? "GET";
    if (method !== "GET" && req.headers[CSRF_HEADER] !== "1") throw new HttpError(403, "طلب مرفوض");
    if (path === "/session") {
      if (method === "GET") return sendJson(res, 200, { authenticated: gate.isAuthenticated(req), required: gate.required });
      if (method === "POST") {
        const body = await readJson(req, 1e4);
        const result = gate.login(req, res, typeof body.password === "string" ? body.password : "");
        if (result === "ok") return sendJson(res, 200, { authenticated: true });
        const [status, message] = LOGIN_MESSAGES[result];
        throw new HttpError(status, message);
      }
      if (method === "DELETE") {
        gate.logout(res);
        return sendJson(res, 200, { authenticated: false });
      }
    }
    if (!gate.isAuthenticated(req)) throw new HttpError(401, "انتهت الجلسة، سجّل الدخول من جديد");
    if (path === "/status" && method === "GET") return sendJson(res, 200, publisher.status());
    if (path === "/media" && method === "GET") return sendJson(res, 200, files.listMedia());
    if (path === "/media" && method === "POST") {
      return sendJson(res, 201, { path: await files.saveUpload(req, url.searchParams.get("name") ?? "") });
    }
    if (path === "/documents" && method === "GET") return sendJson(res, 200, files.listDocuments());
    if (path.startsWith("/documents/")) {
      const document = decodeURIComponent(path.slice("/documents/".length));
      if (method === "GET") return sendJson(res, 200, files.readDocument(document));
      if (method === "PUT") {
        files.writeDocument(document, await readJson(req, MAX_DOCUMENT));
        publisher.afterSave(document);
        return sendJson(res, 200, { ok: true });
      }
    }
    throw new HttpError(404, "طلب غير معروف");
  }
  return (req, res) => route(req, res).catch((error) => sendError(res, error));
}
const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".mov": "video/quicktime",
  ".pdf": "application/pdf",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
  ".ttf": "font/ttf"
};
function resolveStatic(root2, urlPath) {
  let path;
  try {
    path = decodeURIComponent(urlPath);
  } catch {
    return null;
  }
  if (path.includes("\0")) return null;
  let file = resolve(root2, `.${path}`);
  if (file !== root2 && !file.startsWith(root2 + sep)) return null;
  if (existsSync(file) && statSync(file).isDirectory()) file = resolve(file, "index.html");
  return existsSync(file) && statSync(file).isFile() ? file : null;
}
function cacheControl(file, urlPath) {
  if (urlPath.startsWith("/assets/") && /-[A-Za-z0-9_-]{8}\.(js|css)$/.test(file)) return "public, max-age=31536000, immutable";
  if (file.endsWith(".html") || urlPath.startsWith("/data/")) return "no-cache";
  return "public, max-age=86400";
}
function sendFile(req, res, file, stats, urlPath) {
  res.setHeader("Content-Type", TYPES[extname(file).toLowerCase()] ?? "application/octet-stream");
  res.setHeader("Cache-Control", cacheControl(file, urlPath));
  res.setHeader("Last-Modified", stats.mtime.toUTCString());
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("X-Content-Type-Options", "nosniff");
  const since = req.headers["if-modified-since"];
  if (since && Math.floor(stats.mtimeMs / 1e3) <= Math.floor(Date.parse(since) / 1e3)) {
    res.statusCode = 304;
    res.end();
    return;
  }
  const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range ?? "");
  if (range && (range[1] || range[2])) {
    const size = stats.size;
    const start = range[1] ? Number(range[1]) : Math.max(0, size - Number(range[2]));
    const end = range[1] && range[2] ? Math.min(Number(range[2]), size - 1) : size - 1;
    if (start > end || start >= size) {
      res.statusCode = 416;
      res.setHeader("Content-Range", `bytes */${size}`);
      res.end();
      return;
    }
    res.statusCode = 206;
    res.setHeader("Content-Range", `bytes ${start}-${end}/${size}`);
    res.setHeader("Content-Length", end - start + 1);
    if (req.method === "HEAD") {
      res.end();
      return;
    }
    createReadStream(file, { start, end }).pipe(res);
    return;
  }
  res.statusCode = 200;
  res.setHeader("Content-Length", stats.size);
  if (req.method === "HEAD") {
    res.end();
    return;
  }
  createReadStream(file).pipe(res);
}
function createStaticHandler(roots) {
  return (req, res) => {
    if (req.method !== "GET" && req.method !== "HEAD") {
      res.statusCode = 405;
      res.end();
      return;
    }
    const urlPath = new URL(req.url ?? "/", "http://localhost").pathname;
    for (const root2 of roots()) {
      const file = resolveStatic(root2, urlPath);
      if (file) return sendFile(req, res, file, statSync(file), urlPath);
    }
    res.statusCode = 404;
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.end('<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>غير موجود</title><body style="font-family:sans-serif;text-align:center;padding:4rem"><h1>الصفحة غير موجودة</h1><p><a href="/">العودة إلى الرئيسية</a></p></body></html>');
  };
}
const FILM_STYLES = ["cinema", "arch", "frame", "expand"];
const COLLECTION_STYLES = [
  "panels",
  "collage",
  "switch",
  "stagger",
  "strip",
  "duo",
  "journey",
  "spotlight",
  "hotspots",
  "coverflow",
  "moodboard",
  "cabinet",
  "swatches",
  "tiles",
  "mirror",
  "blueprint",
  "lights"
];
class DataError extends Error {
  constructor(path, expected) {
    super(`بيانات غير صحيحة في ${path}: المتوقع ${expected}`);
    this.path = path;
    this.name = "DataError";
  }
}
const isRecord = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
const string = (v, path) => {
  if (typeof v !== "string" || v.trim() === "") throw new DataError(path, "نص غير فارغ");
  return v;
};
const boolean = (v, path) => {
  if (typeof v !== "boolean") throw new DataError(path, "true أو false");
  return v;
};
const numberIn = (min, max) => (v, path) => {
  if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max) {
    throw new DataError(path, `رقم بين ${min} و ${max}`);
  }
  return v;
};
const nullable = (decoder) => (v, path) => v === null || v === void 0 ? null : decoder(v, path);
const array = (decoder) => (v, path) => {
  if (!Array.isArray(v)) throw new DataError(path, "قائمة");
  return v.map((item, i) => decoder(item, `${path}[${i}]`));
};
const oneOf = (options) => (v, path) => {
  if (typeof v !== "string" || !options.includes(v)) {
    throw new DataError(path, `إحدى القيم: ${options.join("، ")}`);
  }
  return v;
};
const hexColor = (v, path) => {
  const s = string(v, path);
  if (!/^#[0-9a-f]{6}$/i.test(s)) throw new DataError(path, "لون HEX مثل #7B5D08");
  return s;
};
const object = (shape) => (v, path) => {
  if (!isRecord(v)) throw new DataError(path, "كائن");
  const out = {};
  for (const key of Object.keys(shape)) {
    out[key] = shape[key](v[key], `${path}.${key}`);
  }
  return out;
};
const tagged = (field, decoders) => (v, path) => {
  if (!isRecord(v)) throw new DataError(path, "كائن");
  const tag = v[field];
  const decoder = typeof tag === "string" ? decoders[tag] : void 0;
  if (!decoder) throw new DataError(`${path}.${field}`, `إحدى القيم: ${Object.keys(decoders).join("، ")}`);
  return decoder(v, path);
};
const ICONS$1 = [
  "sofa",
  "bed",
  "chair",
  "table",
  "tv",
  "mirror",
  "partition",
  "cabinet",
  "curtain",
  "lamp",
  "space",
  "plan",
  "palette",
  "wall",
  "light",
  "pin",
  "mail",
  "phone",
  "web"
];
const icon$1 = oneOf(ICONS$1);
const media = object({
  src: nullable(string),
  caption: string,
  type: nullable(oneOf(["image", "video"])),
  poster: nullable(string),
  aspectRatio: nullable(oneOf(["9:16", "16:9", "auto"]))
});
const film = object({
  style: oneOf(FILM_STYLES),
  kicker: string,
  title: string,
  text: string,
  points: (v, path) => v === void 0 || v === null ? [] : array(string)(v, path),
  video: media
});
const collection = object({
  style: oneOf(COLLECTION_STYLES),
  kicker: string,
  title: string,
  text: string,
  items: array(object({
    title: string,
    image: media,
    tag: nullable(string),
    color: nullable(hexColor),
    spots: (v, path) => v === void 0 || v === null ? [] : array(object({
      x: numberIn(0, 100),
      y: numberIn(0, 100),
      title: string,
      text: string,
      w: nullable(numberIn(1, 100)),
      h: nullable(numberIn(1, 100))
    }))(v, path),
    palette: (v, path) => v === void 0 || v === null ? [] : array(object({ name: string, color: hexColor }))(v, path)
  }))
});
const titledText = object({ title: string, text: string });
const companyDecoder = object({
  name: object({ ar: string, en: string }),
  entityType: string,
  field: string,
  tagline: string,
  closingLine: string,
  hero: nullable(media),
  feature: nullable(object({
    kicker: string,
    title: string,
    en: string,
    text: string,
    cta: string,
    href: string,
    facts: array(string),
    image: media,
    pages: array(media)
  })),
  about: object({ lead: string, highlight: string, paragraphs: array(string), image: media }),
  statements: array(titledText),
  interiorDesign: object({ intro: string, traits: array(string), images: array(media) }),
  films: (v, path) => v === void 0 || v === null ? [] : array(film)(v, path),
  collections: (v, path) => v === void 0 || v === null ? [] : array(collection)(v, path)
});
const servicesDecoder = object({
  intro: string,
  note: string,
  items: array(object({ icon: icon$1, text: string }))
});
const productsDecoder = object({
  intro: string,
  items: array(object({ icon: icon$1, name: string }))
});
const advantagesDecoder = object({ image: media, items: array(titledText) });
const journeyDecoder = object({ intro: string, steps: array(string) });
const levelsDecoder = object({ intro: string, items: array(string) });
const projectBase = {
  id: string,
  name: nullable(string),
  category: string,
  city: nullable(string),
  colors: array(hexColor),
  images: array(media)
};
const standardProject = (layout) => object({ ...projectBase, layout: oneOf([layout]) });
const compareProject = object({
  ...projectBase,
  layout: oneOf(["compare"]),
  before: media,
  after: media
});
const projectDecoders = {
  mosaic: standardProject("mosaic"),
  slideshow: standardProject("slideshow"),
  filmstrip: standardProject("filmstrip"),
  compare: compareProject
};
const projectsDecoder = array(tagged("layout", projectDecoders));
const clientsDecoder = object({
  segments: array(titledText),
  partners: array(object({ name: nullable(string), logo: nullable(string) })),
  credentials: array(object({ title: nullable(string), image: media }))
});
const contactDecoder = object({
  phone: nullable(string),
  whatsapp: nullable(string),
  handle: nullable(string),
  email: nullable(string),
  website: nullable(string),
  address: nullable(string),
  mapQuery: nullable(string),
  mapUrl: nullable(string),
  mapImage: media
});
const ceoDecoder = object({
  title: string,
  name: nullable(string),
  role: string,
  photo: media,
  quote: nullable(string),
  message: array(string),
  signature: nullable(string)
});
const faqDecoder = object({
  intro: string,
  items: array(object({ question: string, answer: string }))
});
const slug = (v, path) => {
  const s = string(v, path);
  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(s)) throw new DataError(path, "اسم ملف بحروف إنجليزية صغيرة وشرطات مثل majlis-design");
  return s;
};
const servicePagesDecoder = array(object({
  slug,
  name: string,
  title: string,
  description: string,
  keywords: array(string),
  kicker: string,
  heading: string,
  lead: string,
  paragraphs: array(string),
  offers: array(string),
  images: array(object({ src: string, caption: string })),
  catalogues: array(string),
  faq: array(object({ question: string, answer: string }))
}));
const cataloguesDecoder = array(object({
  href: string,
  name: object({ ar: string, en: string }),
  place: string,
  kicker: string,
  tagline: string,
  cover: object({ src: string, caption: string }),
  spaces: numberIn(0, 999),
  pieces: numberIn(0, 999),
  materials: numberIn(0, 999),
  film: boolean,
  pages: array(object({ src: string, caption: string }))
}));
const PAGE_FILES = {
  home: "index.html",
  about: "about.html",
  services: "services.html",
  contracting: "contracting.html",
  projects: "projects.html",
  contact: "contact.html"
};
const NAV = [
  { key: "home", href: PAGE_FILES.home, label: "الرئيسية" },
  { key: "about", href: PAGE_FILES.about, label: "من نحن" },
  { key: "services", href: PAGE_FILES.services, label: "الخدمات" },
  { key: "contracting", href: PAGE_FILES.contracting, label: "المقاولات" },
  { key: "projects", href: PAGE_FILES.projects, label: "المشاريع" },
  { key: "contact", href: PAGE_FILES.contact, label: "تواصل معنا" }
];
const NAME = "النظرة الساحرة";
const NAME_EN = "Magic Look";
const esc = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const asset = (root2, src) => esc(`${root2}${encodeURI(src)}`);
function loadSite(root2) {
  const read = (file) => JSON.parse(readFileSync(resolve(root2, "public/data", file), "utf8"));
  const profile = {
    company: companyDecoder(read("company.json"), "company.json"),
    services: servicesDecoder(read("services.json"), "services.json"),
    products: productsDecoder(read("products.json"), "products.json"),
    advantages: advantagesDecoder(read("advantages.json"), "advantages.json"),
    journey: journeyDecoder(read("journey.json"), "journey.json"),
    levels: levelsDecoder(read("levels.json"), "levels.json"),
    projects: projectsDecoder(read("projects.json"), "projects.json"),
    clients: clientsDecoder(read("clients.json"), "clients.json"),
    contact: contactDecoder(read("contact.json"), "contact.json"),
    catalogues: cataloguesDecoder(read("catalogues.json"), "catalogues.json"),
    ceo: ceoDecoder(read("ceo.json"), "ceo.json"),
    faq: faqDecoder(read("faq.json"), "faq.json"),
    servicePages: servicePagesDecoder(read("service-pages.json"), "service-pages.json")
  };
  return { profile, site: read("site.json") };
}
const digits = (s) => s.replace(/\D/g, "");
const telHref = (ctx) => `tel:+966${digits(ctx.profile.contact.phone ?? "").replace(/^0/, "")}`;
const whatsappHref = (ctx, text) => `https://wa.me/${ctx.profile.contact.whatsapp ?? ""}?text=${encodeURIComponent(text)}`;
const quoteText = (subject) => `السلام عليكم، أرغب في طلب عرض سعر: ${subject}`;
const ICONS = {
  phone: '<path d="M6.6 3.5 9 3l1.6 4.2-2 1.5a12 12 0 0 0 6.7 6.7l1.5-2 4.2 1.6-.5 2.4a2.5 2.5 0 0 1-2.6 2C10.700 19 5 13.300 4.600 6.100a2.500 2.500 0 0 1 2-2.600Z"/>',
  chat: '<path d="M12 3.500a8.500 8.500 0 0 0-7.300 12.800L3.500 20.500l4.300-1.100A8.500 8.500 0 1 0 12 3.500Z"/><path d="M9 8.500c-.6.500-.8 1.300-.5 2.200a7 7 0 0 0 4.800 4.800c.9.300 1.700.100 2.200-.5l.5-.8-2-1.200-.8.800a4.500 4.500 0 0 1-2.500-2.500l.8-.8-1.200-2Z"/>',
  pin: '<path d="M12 21s7-6.100 7-11.500a7 7 0 1 0-14 0C5 14.900 12 21 12 21Z"/><circle cx="12" cy="9.500" r="2.500"/>',
  at: '<circle cx="12" cy="12" r="3.800"/><path d="M15.800 8.200v5.300a2.700 2.700 0 0 0 5.200 0V12a9 9 0 1 0-3.700 7.300"/>',
  arrow: '<path d="M19 12H5m6-6-6 6 6 6"/>'
};
const icon = (name) => `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[name]}</svg>`;
const photo = (root2, p, eager = false) => `<img src="${asset(root2, p.src)}" alt="${esc(p.caption)}"${eager ? ' fetchpriority="high"' : ' loading="lazy"'} decoding="async" />`;
const pad2 = (n) => String(n).padStart(2, "0");
const PATTERN = '<div class="pattern pattern-tile" aria-hidden="true"></div>';
const stagger = (i, every = 3) => `style="--i:${i % every}"`;
const titleCase = (s) => s.toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase());
const counter = () => {
  let n = 0;
  return () => ++n;
};
const section = (p, body) => `
    <section${p.id ? ` id="${esc(p.id)}"` : ""}${p.className ? ` class="${p.className}"` : ""}>${p.pattern ? `
      ${PATTERN}` : ""}
      <div class="wrap">
        <div class="s-head reveal">
          <span class="no latin">${pad2(p.number)}</span>
          <h2>${esc(p.title)}</h2>${p.intro ? `
          <p>${esc(p.intro)}</p>` : ""}
        </div>${body}
      </div>
    </section>`;
const link = (href, label, kind = "solid", external = false) => `<a class="btn ${kind}" href="${esc(href)}"${external ? ' target="_blank" rel="noopener"' : ""}>${esc(label)}</a>`;
const whatsappLink = (ctx, text, label, kind = "ghost") => `<a class="btn ${kind}" href="${esc(whatsappHref(ctx, text))}" target="_blank" rel="noopener">${icon("chat")}${esc(label)}</a>`;
const crumbs = (root2, items) => `
          <nav class="crumbs" aria-label="مسار التنقل"><ol>
            <li><a href="${root2}index.html">الرئيسية</a></li>
            ${items.map((c) => c.href ? `<li><a href="${esc(c.href)}">${esc(c.label)}</a></li>` : `<li aria-current="page">${esc(c.label)}</li>`).join("\n            ")}
          </ol></nav>`;
const pageHero = (p) => `
    <header class="hero hero-with-media pg-hero" id="top">
      <figure class="media hero-background">${photo(p.root, p.image, true)}</figure>
      <div class="hero-shade" aria-hidden="true"></div>
      ${PATTERN}
      <div class="wrap">
        <div class="hero-copy">${crumbs(p.root, p.trail)}
          <p class="eyebrow">${esc(p.kicker)}</p>
          <h1 id="page-title">${esc(p.heading)}</h1>
          <p class="tag">${esc(p.lead)}</p>
          <div class="ctas">${p.actions}</div>
        </div>
        <div class="hero-art" aria-hidden="true">
          <div class="frame">
            <div class="ring"></div><div class="ring r2"></div>
            <i class="corner tr"></i><i class="corner bl"></i>
            <img class="big" src="${p.root}assets/brand/symbol-on-green.svg" alt="" />
          </div>
        </div>
      </div>
    </header>`;
const closingBand = (ctx, root2, title, text, query, subject) => `
    <section class="journey closing">
      ${PATTERN}
      <div class="wrap closing-in reveal">
        <div>
          <h2>${esc(title)}</h2>
          <p>${esc(text)}</p>
        </div>
        <div class="ctas">
          ${link(`${root2}contact.html${query}#quote`, "اطلب عرض سعر")}
          ${whatsappLink(ctx, quoteText(subject), "راسلنا على واتساب")}
        </div>
      </div>
    </section>`;
const projectCard = (root2, c, i) => `
          <li class="reveal" ${stagger(i, 2)} data-place="${esc(c.place)}"><a class="pj-card" href="${root2}${esc(c.href)}">
            ${photo(root2, c.cover)}
            <span class="pj-text">
              <em>${esc(c.place)}</em>
              <b>${esc(c.name.ar)}</b>
              <i class="latin">${esc(titleCase(c.name.en))}</i>
              <small>${esc(c.tagline)}</small>
              <span class="pj-open">افتح الكتالوج <span aria-hidden="true">←</span></span>
            </span>
          </a></li>`;
const faqList = (items) => `
        <div class="faq-list">
          ${items.map((q, i) => `<details class="faq-item reveal" ${stagger(i, 5)}><summary><h3>${esc(q.question)}</h3></summary><p>${esc(q.answer)}</p></details>`).join("\n          ")}
        </div>`;
const offers = (title, items) => `
          <div class="offers reveal">
            <h3>${esc(title)}</h3>
            <ul>${items.map((s) => `<li>${esc(s)}</li>`).join("")}</ul>
          </div>`;
const filmBand = (root2, number, video, poster, title, text, silentLoop = false) => `
    <section class="journey pg-film">
      ${PATTERN}
      <div class="wrap pg-film-in">
        <div class="reveal">
          <span class="no latin">${pad2(number)}</span>
          <h2>${esc(title)}</h2>
          <p>${esc(text)}</p>
        </div>
        <div class="pg-film-box reveal">
          <i class="corner tr" aria-hidden="true"></i><i class="corner bl" aria-hidden="true"></i>
          <video controls ${silentLoop ? 'data-silent-loop muted loop preload="metadata"' : 'preload="none"'} playsinline${poster ? ` poster="${asset(root2, poster)}"` : ""} aria-label="${esc(title)}">
            <source src="${asset(root2, video)}" type="video/mp4" />
          </video>
        </div>
      </div>
    </section>`;
function siteHeader(root2, active) {
  return `<a class="skip" href="#main">تخطَّ إلى المحتوى</a>
    <nav class="nav" id="nav" aria-label="التنقل الرئيسي">
      <div class="wrap">
        <a class="brand" href="${root2}index.html" aria-label="${NAME} ${NAME_EN}، الصفحة الرئيسية">
          <img class="logo" src="${root2}assets/brand/logo-on-light.svg" alt="" width="173" height="40" />
        </a>
        <ul>
          ${NAV.map((n) => `<li><a href="${root2}${n.href}"${n.key === active ? ' class="active" aria-current="page"' : ""}>${n.label}</a></li>`).join("\n          ")}
        </ul>
        <span class="nav-search" data-site-search></span>
      </div>
    </nav>`;
}
function siteFooter(ctx, root2) {
  const { contact, servicePages, company } = ctx.profile;
  const hello = whatsappHref(ctx, "السلام عليكم، أرغب في الاستفسار عن خدماتكم");
  return `<footer class="site-footer">
      ${PATTERN}
      <div class="wrap">
        <div class="footer-main footer-wide">
          <div class="footer-brand">
            <a href="${root2}index.html" aria-label="${NAME} ${NAME_EN}"><img class="logo" src="${root2}assets/brand/logo-on-green.svg" alt="" width="173" height="40" loading="lazy" /></a>
            <p>${esc(company.tagline)}</p>
          </div>
          <div class="footer-col">
            <h2>تصفّح</h2>
            <ul>${NAV.map((n) => `<li><a href="${root2}${n.href}">${n.label}</a></li>`).join("")}</ul>
          </div>
          <div class="footer-col">
            <h2>الخدمات</h2>
            <ul>${servicePages.map((s) => `<li><a href="${root2}services/${esc(s.slug)}.html">${esc(s.name)}</a></li>`).join("")}</ul>
          </div>
          <div class="footer-col">
            <h2>تواصل معنا</h2>
            <ul>
              <li><a href="${telHref(ctx)}"><bdi dir="ltr">${esc(contact.phone ?? "")}</bdi></a></li>
              <li><a href="${esc(hello)}" target="_blank" rel="noopener">واتساب</a></li>
              <li><bdi dir="ltr">${esc(contact.handle ?? "")}</bdi></li>
              <li><a href="${esc(contact.mapUrl ?? "")}" target="_blank" rel="noopener">${esc(contact.address ?? "")}</a></li>
            </ul>
            <a class="footer-cta" href="${root2}contact.html#quote">ابدأ مشروعك</a>
          </div>
        </div>
        <div class="footer-bar">
          <p>© ${(/* @__PURE__ */ new Date()).getFullYear()} ${NAME} · ${NAME_EN}</p>
          <a href="#main">العودة إلى الأعلى</a>
        </div>
      </div>
    </footer>
    <a class="wa-float" href="${esc(hello)}" target="_blank" rel="noopener" aria-label="راسلنا على واتساب">${icon("chat")}</a>`;
}
const projectsByHref = (ctx, hrefs) => hrefs.map((h) => ctx.profile.catalogues.find((c) => c.href === h)).filter((c) => c !== void 0);
const heroPhoto = (ctx, image) => image ?? { src: ctx.profile.company.hero?.poster ?? "images/hero-poster.webp", caption: "" };
function serviceGallery(ctx, page) {
  const items = /* @__PURE__ */ new Map();
  const add = (src, caption, id) => {
    const item = items.get(src) ?? { src, caption, ids: [] };
    if (id) item.ids.push(id);
    items.set(src, item);
  };
  page.images.forEach((i) => add(i.src, i.caption));
  for (const n of ctx.site.serviceCollections[page.slug] ?? []) {
    ctx.profile.company.collections[n - 1]?.items.forEach((item, j) => {
      if (item.image.src) add(item.image.src, item.image.caption, `collection-${n}-${j + 1}`);
    });
  }
  return [...items.values()];
}
function servicePageHtml(page, ctx) {
  const r = "../";
  const t = esc;
  const [hero, ...gallery] = serviceGallery(ctx, page);
  const related = projectsByHref(ctx, page.catalogues);
  const others = ctx.profile.servicePages.filter((p) => p.slug !== page.slug);
  const filmIndex = ctx.site.serviceFilms[page.slug];
  const pageFilm = filmIndex === void 0 ? void 0 : ctx.profile.company.films[filmIndex];
  const anchors = (ids) => ids.map((id) => `<span class="anchor" id="${t(id)}"></span>`).join("");
  const query = `?service=${encodeURIComponent(page.slug)}`;
  const next = counter();
  return `<!-- Generated from public/data by tooling/vite/site.ts on every build. Edit the data, not this file. -->
<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8" />
    <meta name="color-scheme" content="only light" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta name="description" content="${t(page.description)}" />
    <meta name="theme-color" content="#F7F4F0" />
    <title>${t(page.title)}</title>
    <link rel="icon" type="image/svg+xml" href="../assets/favicon.svg" />
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32.png" />
    <link rel="apple-touch-icon" href="../assets/apple-touch-icon.png" />${hero ? `
    <link rel="preload" as="image" href="${asset(r, hero.src)}" fetchpriority="high" />` : ""}
  </head>
  <body class="site" data-page="service" data-service="${t(page.slug)}" data-root="../">
    ${siteHeader(r, "services")}
    <main id="main">${pageHero({
    root: r,
    kicker: page.kicker,
    heading: page.heading,
    lead: page.lead,
    image: heroPhoto(ctx, hero),
    trail: [{ label: "الخدمات", href: "../services.html" }, { label: page.name }],
    actions: `${link(`../contact.html${query}#quote`, "اطلب عرض سعر")}${whatsappLink(ctx, quoteText(page.name), "واتساب")}`
  })}
      ${hero ? anchors(hero.ids) : ""}
${section({ number: next(), title: `${page.name} كما نراها`, className: "about" }, `
        <div class="pg-split">
          <div class="pg-copy">
            ${page.paragraphs.map((p, i) => `<p class="${i === 0 ? "pg-lead " : ""}reveal">${t(p)}</p>`).join("\n            ")}
          </div>${offers("تشمل الخدمة", page.offers)}
        </div>`)}
${gallery.length > 0 ? section({ number: next(), title: `من أعمالنا في ${page.name}`, className: "services" }, `
        <div class="gallery">
          ${gallery.map((g) => `<figure data-zoom>${anchors(g.ids)}${photo(r, g)}<figcaption>${t(g.caption)}</figcaption></figure>`).join("\n          ")}
        </div>`) : ""}
${pageFilm?.video.src ? filmBand(r, next(), pageFilm.video.src, pageFilm.video.poster ?? null, pageFilm.title, pageFilm.text) : ""}
${related.length > 0 ? section({ number: next(), title: "مشاريع ذات صلة" }, `
        <ul class="pj-grid">${related.map((c, i) => projectCard(r, c, i)).join("")}
        </ul>`) : ""}
${page.faq.length > 0 ? section({ number: next(), title: `أسئلة عن ${page.name}`, className: "services" }, faqList(page.faq)) : ""}
${closingBand(ctx, r, `اطلب عرض سعر لـ${page.name}`, ctx.profile.company.closingLine, query, page.name)}

    <section class="more-services">
      <div class="wrap">
        <nav class="svc-pages" aria-label="خدمات أخرى">
          <h3>خدمات أخرى</h3>
          <ul>
            ${others.map((o) => `<li><a href="${t(o.slug)}.html">${t(o.name)}</a></li>`).join("\n            ")}
          </ul>
        </nav>
      </div>
    </section>
    </main>
    ${siteFooter(ctx, r)}
    <script type="module" src="/src/entries/site.ts"><\/script>
  </body>
</html>
`;
}
const SERVICES_DIR = "services";
const servicePath = (slug2) => `${SERVICES_DIR}/${slug2}.html`;
function writeServicePages(root2) {
  const ctx = loadSite(root2);
  const pages = ctx.profile.servicePages;
  const paths2 = projectPaths(root2);
  const dir = paths2.page(SERVICES_DIR);
  mkdirSync(dir, { recursive: true });
  const keep = new Set(pages.map((p) => `${p.slug}.html`));
  for (const f of readdirSync(dir)) if (f.endsWith(".html") && !keep.has(f)) rmSync(resolve(dir, f));
  return pages.map((page) => {
    const file = paths2.page(servicePath(page.slug));
    writeFileSync(file, servicePageHtml(page, ctx));
    return file;
  });
}
const CATALOGUE = /^(villa-wood\.json|projects\/.+\.json)$/;
function regeneratePages(root2, path) {
  if (CATALOGUE.test(path)) {
    execFileSync(process.execPath, [resolve(root2, "tooling/scripts/catalogue-pages.mjs")], { cwd: root2 });
  }
  writeServicePages(root2);
}
const KEEP_RELEASES = 3;
const DEBOUNCE_MS = 1500;
class SiteBuilder {
  constructor(root2, releasesDir) {
    this.root = root2;
    this.releasesDir = releasesDir;
    mkdirSync(releasesDir, { recursive: true });
    const pointer = this.pointerFile();
    if (existsSync(pointer)) {
      const dir = resolve(releasesDir, readFileSync(pointer, "utf8").trim());
      if (existsSync(resolve(dir, "index.html"))) this.current = dir;
    }
  }
  current = null;
  building = false;
  pending = false;
  timer = null;
  last = { state: "live", updatedAt: null, message: null };
  /** The folder the site is served from, or null before the first build. */
  currentRoot() {
    return this.current;
  }
  /**
   * Builds a fresh release at start-up, so a code update shows without waiting for a save.
   * The previous release keeps serving until the new one is ready.
   */
  ensureRelease() {
    void this.build();
  }
  afterSave(path) {
    try {
      regeneratePages(this.root, path);
    } catch (error) {
      this.last = { state: "failed", updatedAt: (/* @__PURE__ */ new Date()).toISOString(), message: error.message };
      return;
    }
    this.last = { ...this.last, state: "building" };
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.build(), DEBOUNCE_MS);
  }
  status() {
    return this.last;
  }
  pointerFile() {
    return resolve(this.releasesDir, "current.txt");
  }
  async build() {
    if (this.building) {
      this.pending = true;
      return;
    }
    this.building = true;
    this.last = { ...this.last, state: "building", message: null };
    const id = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    const dir = resolve(this.releasesDir, id);
    try {
      await this.runVite(dir);
      this.current = dir;
      writeFileSync(this.pointerFile(), id);
      this.last = { state: "live", updatedAt: (/* @__PURE__ */ new Date()).toISOString(), message: null };
      this.prune();
      console.log(`[publish] release ${id} is live`);
    } catch (error) {
      rmSync(dir, { recursive: true, force: true });
      this.last = { state: "failed", updatedAt: (/* @__PURE__ */ new Date()).toISOString(), message: error.message };
      console.error(`[publish] build failed: ${error.message}`);
    } finally {
      this.building = false;
      if (this.pending) {
        this.pending = false;
        void this.build();
      }
    }
  }
  runVite(outDir) {
    return new Promise((done, fail) => {
      const vite = resolve(this.root, "node_modules/vite/bin/vite.js");
      const child = spawn(process.execPath, [vite, "build", "--outDir", outDir, "--emptyOutDir", "--logLevel", "warn"], {
        cwd: this.root,
        env: { ...process.env, SITE_SKIP_PUBLIC: "1" },
        windowsHide: true
      });
      let log = "";
      const collect = (chunk) => {
        log = (log + chunk.toString()).slice(-4e3);
      };
      child.stdout.on("data", collect);
      child.stderr.on("data", collect);
      child.on("error", fail);
      child.on("close", (code) => code === 0 ? done() : fail(new Error(log.trim() || `vite exited with ${code}`)));
    });
  }
  /** Keeps the newest releases. A folder still in use on Windows is left for the next time. */
  prune() {
    const releases = readdirSync(this.releasesDir, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => e.name).sort();
    for (const old of releases.slice(0, Math.max(0, releases.length - KEEP_RELEASES))) {
      const dir = resolve(this.releasesDir, old);
      if (dir === this.current) continue;
      try {
        rmSync(dir, { recursive: true, force: true });
      } catch {
      }
    }
  }
}
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const paths = projectPaths(root);
const config = loadConfig(root);
const builder = new SiteBuilder(root, paths.releases);
const content = createContentHandler({
  files: new ContentFiles({ data: paths.data, public: paths.public, history: paths.history }),
  publisher: builder,
  gate: new SessionAuth(config)
});
const serveStatic = createStaticHandler(() => {
  const release = builder.currentRoot();
  return release ? [release, paths.public] : [];
});
const server = createServer((req, res) => {
  const path = req.url ?? "/";
  if (path === CONTENT_API || path.startsWith(`${CONTENT_API}/`) || path.startsWith(`${CONTENT_API}?`)) {
    void content(req, res);
    return;
  }
  if (!builder.currentRoot()) {
    res.statusCode = 503;
    res.setHeader("Retry-After", "30");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.end('<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta http-equiv="refresh" content="15"><body style="font-family:sans-serif;text-align:center;padding:4rem"><h1>يُجهَّز الموقع…</h1><p>ستفتح الصفحة تلقائياً بعد لحظات.</p></body></html>');
    return;
  }
  if (path.startsWith("/dashboard")) {
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
  }
  serveStatic(req, res);
});
server.listen(config.port, config.host, () => {
  console.log(`Magic Look: http://${config.host === "0.0.0.0" ? "localhost" : config.host}:${config.port}/`);
  console.log(`Dashboard:  http://localhost:${config.port}/dashboard.html`);
  if (!config.passwordHash) console.warn('No dashboard password yet: run "npm run set-password".');
  builder.ensureRelease();
});
